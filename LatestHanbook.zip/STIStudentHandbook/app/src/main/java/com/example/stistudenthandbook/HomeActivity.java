 package com.example.stistudenthandbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

 public class HomeActivity extends AppCompatActivity {

    ImageButton CalcuIbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        CalcuIbtn = findViewById(R.id.ibtnCalcu);

        CalcuIbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCalcu = new Intent (HomeActivity.this, GradeCalcularor.class);
                startActivity(intentCalcu);
            }
        });
    }
}